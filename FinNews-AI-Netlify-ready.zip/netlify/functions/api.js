const DEFAULT_MODEL = process.env.GROQ_MODEL || "llama-3.3-70b-versatile";
const NEWS_KEY = (process.env.NEWS_API_KEY || "").trim();
const GROQ_KEY = (process.env.GROQ_API_KEY || "").trim();

const DEMO_ARTICLES = [
  {
    id: "demo-1",
    title: "Global markets watch interest rates and inflation data",
    description: "Investors are monitoring inflation and central-bank policy for clues about the direction of borrowing costs.",
    content: "Markets continue to focus on inflation, interest rates, economic growth and company earnings. Changes in borrowing costs can affect consumer spending, business investment and the valuation of financial assets.",
    source: "FinNews AI Demo",
    author: null,
    published_at: new Date().toISOString(),
    url: "https://example.com/finnews-demo-1",
    image_url: null
  },
  {
    id: "demo-2",
    title: "Technology companies focus on artificial intelligence investment",
    description: "Large technology firms continue to invest in AI infrastructure and software as businesses explore new uses for the technology.",
    content: "Technology companies are increasing investment in computing infrastructure and artificial intelligence products. Investors are watching revenue growth, costs and the pace at which AI products become commercially useful.",
    source: "FinNews AI Demo",
    author: null,
    published_at: new Date(Date.now() - 3600000).toISOString(),
    url: "https://example.com/finnews-demo-2",
    image_url: null
  },
  {
    id: "demo-3",
    title: "Oil prices remain important for inflation and transport costs",
    description: "Changes in energy prices can affect fuel costs, production expenses and the prices consumers pay for goods and services.",
    content: "Oil is an important input for transportation and many industrial processes. A sustained change in energy prices can influence company costs, household budgets and inflation measures.",
    source: "FinNews AI Demo",
    author: null,
    published_at: new Date(Date.now() - 7200000).toISOString(),
    url: "https://example.com/finnews-demo-3",
    image_url: null
  },
  {
    id: "demo-4",
    title: "Banks monitor lending demand and credit conditions",
    description: "Bank earnings and lending activity are influenced by interest rates, deposits, loan demand and credit quality.",
    content: "Banks earn revenue from financial services and the difference between interest received on loans and interest paid on funding. Credit quality and loan demand are important factors for bank performance.",
    source: "FinNews AI Demo",
    author: null,
    published_at: new Date(Date.now() - 10800000).toISOString(),
    url: "https://example.com/finnews-demo-4",
    image_url: null
  },
  {
    id: "demo-5",
    title: "Investors track company earnings for signs of business growth",
    description: "Quarterly earnings reports provide information about revenue, profit, costs and management expectations.",
    content: "Company earnings reports help investors understand how a business performed during a period. Revenue, profit margins, cash flow and forward guidance are commonly monitored measures.",
    source: "FinNews AI Demo",
    author: null,
    published_at: new Date(Date.now() - 14400000).toISOString(),
    url: "https://example.com/finnews-demo-5",
    image_url: null
  },
  {
    id: "demo-6",
    title: "Currency movements affect companies that trade internationally",
    description: "Exchange-rate changes can alter the value of overseas sales, imported inputs and international investments.",
    content: "Companies operating across countries can be affected by currency movements. A stronger or weaker domestic currency can change the reported value of foreign revenue and the cost of imported goods.",
    source: "FinNews AI Demo",
    author: null,
    published_at: new Date(Date.now() - 18000000).toISOString(),
    url: "https://example.com/finnews-demo-6",
    image_url: null
  }
];

const json = (body, status = 200) => ({
  statusCode: status,
  headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  body: JSON.stringify(body)
});

function normaliseArticle(a, i) {
  return {
    id: a.url || `news-${i}-${Date.now()}`,
    title: a.title || "Untitled article",
    description: a.description || "",
    content: a.content || a.description || "",
    source: a.source?.name || "Unknown source",
    author: a.author || null,
    published_at: a.publishedAt || null,
    url: a.url || "#",
    image_url: a.urlToImage || null
  };
}

function demoFilter(query, category) {
  let list = [...DEMO_ARTICLES];
  if (query) {
    const q = query.toLowerCase();
    list = list.filter(a => `${a.title} ${a.description} ${a.content}`.toLowerCase().includes(q));
  }
  if (category && category !== "all") {
    const categoryTerms = {
      business: ["business", "company", "companies", "bank"],
      markets: ["market", "investor", "investors"],
      stocks: ["stock", "shares", "earnings", "company"],
      economy: ["inflation", "interest", "economy", "growth"],
      technology: ["technology", "ai", "artificial intelligence"],
      banking: ["bank", "lending", "credit"],
      cryptocurrency: ["crypto", "bitcoin", "blockchain"]
    };
    const terms = categoryTerms[category];
    if (terms) list = list.filter(a => terms.some(t => `${a.title} ${a.description}`.toLowerCase().includes(t)));
  }
  return list;
}

async function fetchNews({ category, query, page, pageSize }) {
  if (!NEWS_KEY || NEWS_KEY === "your_newsapi_key") {
    const demo = demoFilter(query, category);
    const start = (page - 1) * pageSize;
    return { status: "success", demo: true, cached: false, total_results: demo.length, page, articles: demo.slice(start, start + pageSize) };
  }

  const params = new URLSearchParams();
  params.set("page", String(page));
  params.set("pageSize", String(Math.min(pageSize, 20)));
  params.set("language", "en");
  if (query) {
    params.set("q", query);
    params.set("sortBy", "publishedAt");
  } else if (category && category !== "all" && ["business", "technology"].includes(category)) {
    params.set("country", "us");
    params.set("category", category);
  } else {
    params.set("q", "finance OR markets OR stocks OR economy");
    params.set("sortBy", "publishedAt");
  }

  const endpoint = query || (category && ["business", "technology"].includes(category))
    ? "https://newsapi.org/v2/top-headlines"
    : "https://newsapi.org/v2/everything";

  // NewsAPI requires different parameter combinations for top-headlines/everything.
  if (endpoint.endsWith("top-headlines") && query) {
    params.delete("country");
    params.delete("category");
  }
  const url = `${endpoint}?${params.toString()}`;
  const res = await fetch(url, { headers: { "X-Api-Key": NEWS_KEY } });
  const data = await res.json().catch(() => ({}));

  if (!res.ok || data.status !== "ok") {
    const msg = data.message || "News service is temporarily unavailable.";
    // Keep the UI usable if NewsAPI is unavailable.
    return { status: "success", demo: true, cached: false, total_results: DEMO_ARTICLES.length, page, articles: demoFilter(query, category).slice(0, pageSize), warning: msg };
  }

  return {
    status: "success",
    demo: false,
    cached: false,
    total_results: Number(data.totalResults || 0),
    page,
    articles: (data.articles || []).map(normaliseArticle)
  };
}

function extractJson(text) {
  const cleaned = String(text || "").replace(/```json\s*/gi, "").replace(/```\s*/g, "").trim();
  try { return JSON.parse(cleaned); } catch {}
  const match = cleaned.match(/\{[\s\S]*\}/);
  if (match) {
    try { return JSON.parse(match[0]); } catch {}
  }
  return null;
}

function demoSummary(title, description, content) {
  const source = `${description} ${content}`.trim();
  return {
    simple_summary: source || `This article discusses ${title}.`,
    what_happened: `The article explains the main financial development described in “${title}”.`,
    why_it_matters: "Financial news can affect how investors, businesses and consumers understand markets and the economy.",
    financial_terms: [
      { term: "Inflation", meaning: "A broad rise in the prices of goods and services over time." },
      { term: "Interest rate", meaning: "The cost of borrowing money or the return earned on lending or saving." }
    ],
    key_takeaways: [
      "Focus on the facts and numbers reported in the article.",
      "Market prices can change for many different reasons."
    ],
    market_context: "This is a demo explanation because a Groq API key is not configured.",
    disclaimer: "AI-generated summary for informational purposes only. This is not financial advice."
  };
}

async function simplify(title, description, content) {
  const combined = `${title || ""} ${description || ""} ${content || ""}`.trim();
  if (combined.length < 40) return json({ status: "error", message: "Not enough article text to simplify (need at least 40 characters)." }, 422);

  if (!GROQ_KEY || GROQ_KEY === "your_groq_api_key") {
    return json({ status: "success", demo: true, cached: false, summary: demoSummary(title, description, content) });
  }

  const prompt = `You simplify financial news for beginners. Return ONLY valid JSON with these keys:
simple_summary (string), what_happened (string), why_it_matters (string),
financial_terms (array of objects with term and meaning), key_takeaways (array of strings),
market_context (string), disclaimer (string).
Do not give investment advice or tell the user to buy, sell, or hold.
Article title: ${title}
Description: ${description}
Content: ${content}`.slice(0, 26000);

  const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${GROQ_KEY}` },
    body: JSON.stringify({
      model: DEFAULT_MODEL,
      temperature: 0.2,
      max_tokens: 900,
      messages: [
        { role: "system", content: "You produce concise, accurate educational financial-news explanations. Output JSON only." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    })
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const status = res.status === 429 ? 429 : 502;
    return json({ status: "error", message: status === 429 ? "AI rate limit reached. Please wait and try again." : "The AI service is temporarily unavailable." }, status);
  }

  const parsed = extractJson(data.choices?.[0]?.message?.content);
  if (!parsed?.simple_summary) {
    return json({ status: "error", message: "The AI returned an unexpected response. Please try again." }, 502);
  }
  parsed.financial_terms = Array.isArray(parsed.financial_terms) ? parsed.financial_terms : [];
  parsed.key_takeaways = Array.isArray(parsed.key_takeaways) ? parsed.key_takeaways : [];
  parsed.disclaimer = parsed.disclaimer || "AI-generated summary for informational purposes only. This is not financial advice.";

  return json({ status: "success", demo: false, cached: false, summary: parsed });
}

exports.handler = async (event) => {
  const method = event.httpMethod || "GET";
  const path = event.path || "";
  const route = path.replace(/^.*\/api\/?/, "").replace(/^\/+|\/+$/g, "");

  try {
    if (method === "OPTIONS") return json({ status: "success" });
    if (method === "GET" && (route === "health" || route === "")) {
      return json({
        status: "healthy",
        service: "FinNews AI",
        news_mode: NEWS_KEY ? "live" : "demo",
        ai_mode: GROQ_KEY ? "live" : "demo"
      });
    }

    if (method === "GET" && route === "news") {
      const q = event.queryStringParameters || {};
      const category = q.category || "all";
      const query = (q.q || "").trim().slice(0, 100);
      const page = Math.max(1, Number.parseInt(q.page || "1", 10) || 1);
      const pageSize = Math.min(20, Math.max(1, Number.parseInt(q.page_size || "6", 10) || 6));
      return json(await fetchNews({ category, query, page, pageSize }));
    }

    if (method === "POST" && route === "simplify") {
      let body = {};
      try { body = JSON.parse(event.body || "{}"); } catch {
        return json({ status: "error", message: "Invalid JSON request." }, 400);
      }
      return await simplify(
        String(body.title || "").slice(0, 500),
        String(body.description || "").slice(0, 2000),
        String(body.content || "").slice(0, 20000)
      );
    }

    return json({ status: "error", message: "Not found." }, 404);
  } catch (err) {
    console.error("FinNews function error:", err?.message || err);
    return json({ status: "error", message: "Something went wrong on our side. Please try again." }, 500);
  }
};
